import * as THREE from 'three';
import { CHAMBER, GAME_BALANCE, LEVELS } from './config';
import { GameState } from './types';
import { StateMachine } from './GameState';
import { SceneManager } from './SceneManager';
import { PhysicsManager } from './PhysicsManager';
import { BallManager } from './BallManager';
import { DropController } from './DropController';
import { InputManager } from './InputManager';
import { ScoreManager } from './ScoreManager';
import { MergeManager } from './MergeManager';
import { EffectsManager } from './EffectsManager';
import { AudioManager } from './AudioManager';
import { StorageManager } from './StorageManager';
import { UIManager } from './UIManager';

export class Game {
  private states=new StateMachine();private scene!:SceneManager;private physics=new PhysicsManager();private balls!:BallManager;
  private dropper!:DropController;private input!:InputManager;private score=new ScoreManager();private effects!:EffectsManager;
  private audio=new AudioManager();private ui=new UIManager();private saved=StorageManager.load();
  private raf=0;private lastFrame=0;private dangerStart=0;private dangerCandidatesSince=0;private dropCount=0;private reduced=false;
  private tutorialStep=0;private disposed=false;
  async init():Promise<void>{
    const canvas=document.getElementById('game-canvas') as HTMLCanvasElement;
    this.scene=new SceneManager(canvas);await this.physics.init();
    this.balls=new BallManager(this.scene.world,this.physics.world);this.effects=new EffectsManager(this.scene.world);
    this.dropper=new DropController(this.scene.world,this.balls);
    this.input=new InputManager(canvas,this.scene,this.dropper,this.states,()=>this.drop(),()=>this.togglePause());
    this.states.onChange(s=>{this.ui.setState(s);if(s===GameState.Playing||s===GameState.Danger)this.ui.showScreen(null);});
    this.ui.score(0,this.saved.highScore);this.ui.sound(this.saved.soundEnabled);this.audio.setEnabled(this.saved.soundEnabled);
    this.bindUI();this.states.set(GameState.Ready);this.ui.showScreen('start-screen');this.ui.setState(GameState.Ready);
    window.addEventListener('resize',this.resize);document.addEventListener('visibilitychange',this.visibility);
    this.raf=requestAnimationFrame(this.frame);
  }
  private bindUI():void {
    this.ui.bind('play-btn',()=>this.start());this.ui.bind('retry-btn',()=>this.start());this.ui.bind('restart-pause-btn',()=>this.start());
    this.ui.bind('resume-btn',()=>this.resume());this.ui.bind('pause-btn',()=>this.togglePause());
    document.getElementById('reset-view-btn')?.addEventListener('click',()=>this.scene.resetView());
    this.ui.bind('sound-btn',()=>{this.saved.soundEnabled=!this.saved.soundEnabled;this.audio.setEnabled(this.saved.soundEnabled);this.ui.sound(this.saved.soundEnabled);StorageManager.save(this.saved);});
  }
  private start():void {
    if(this.states.state===GameState.GameOver)this.states.set(GameState.Ready);
    if(this.states.state===GameState.Paused)this.states.set(GameState.Ready);
    this.mergeManager.reset();this.balls.clear();this.dropper.reset();this.score.reset();this.effects.reset();
    this.physics.resetClock();this.dangerStart=0;this.dangerCandidatesSince=0;this.dropCount=0;this.ui.clearDanger();this.ui.combo(0,0);
    this.saved.gamesPlayed++;StorageManager.save(this.saved);
    this.states.set(GameState.Playing);this.dropper.readyForNext();this.ui.next(LEVELS[this.dropper.nextLevel-1].name,LEVELS[this.dropper.nextLevel-1].color);
    this.ui.score(0,this.saved.highScore);this.ui.showScreen(null);this.lastFrame=performance.now();
    if(!this.saved.tutorialCompleted)this.ui.hint('TRASCINA PER MUOVERE · RILASCIA PER CADERE');
  }
  private drop():void {
    if(!this.states.canPlay())return;
    const ball=this.dropper.drop(performance.now());if(!ball)return;
    this.audio.drop();this.dropCount++;this.dropper.setEnabled(false);
    this.ui.next(LEVELS[this.dropper.nextLevel-1].name,LEVELS[this.dropper.nextLevel-1].color);
    if(this.dropCount===1&&!this.saved.tutorialCompleted)this.ui.hint('RILASCIA PER LASCIARE CADERE');
    window.setTimeout(()=>{if(this.states.canPlay())this.dropper.readyForNext();},GAME_BALANCE.spawnCooldownMs);
  }
  private resume():void {if(this.states.state===GameState.Paused)this.states.set(GameState.Playing);this.physics.resetClock();}
  private togglePause():void {
    if(this.states.state===GameState.Playing||this.states.state===GameState.Danger){this.states.set(GameState.Paused);this.ui.showScreen('pause-screen');}
    else if(this.states.state===GameState.Paused)this.resume();
  }
  private checkDanger(now:number):void {
    const active=this.balls.all.filter(b=>b.status==='active');
    const above=active.some(b=>this.balls.position(b).y+LEVELS[b.level-1].radius>CHAMBER.criticalLineY);
    const dangerous=active.some(b=>{
      const p=this.balls.position(b),v=this.balls.velocity(b);
      return p.y+LEVELS[b.level-1].radius>CHAMBER.criticalLineY&&Math.abs(v.y)<3.2;
    });
    if(dangerous){
      if(!this.dangerCandidatesSince)this.dangerCandidatesSince=now;
      if(this.states.state===GameState.Playing&&now-this.dangerCandidatesSince>=GAME_BALANCE.dangerEntryDelayMs){
        this.states.set(GameState.Danger);this.dangerStart=now;this.ui.hint('NON SUPERARE LA LINEA');
      }
    }else{
      this.dangerCandidatesSince=0;
      if(!above&&this.states.state===GameState.Danger){this.states.set(GameState.Playing);this.ui.clearDanger();this.ui.hint('SAVED');}
    }
    if(this.states.state===GameState.Danger&&above){
      const left=Math.max(0,GAME_BALANCE.gameOverCountdownMs-(now-this.dangerStart));
      this.ui.danger(left/1000);
      if(Math.floor(left/500)!==Math.floor((left+16)/500))this.audio.danger(1-left/3000);
      if(left<=0)this.endGame();
    }
  }
  private endGame():void {
    if(this.states.state!==GameState.Danger)return;this.states.set(GameState.GameOver);this.audio.gameOver();this.dropper.setEnabled(false);
    const newRecord=this.score.score>this.saved.highScore;if(newRecord){this.saved.highScore=this.score.score;this.audio.record();}
    this.saved.highestBallLevel=Math.max(this.saved.highestBallLevel,this.score.highestLevel);this.saved.bestCombo=Math.max(this.saved.bestCombo,this.score.bestCombo);
    this.saved.tutorialCompleted=this.saved.tutorialCompleted||this.dropCount>=1;StorageManager.save(this.saved);
    this.scene.shake(.12,250);this.ui.gameOver(this.score.score,this.saved.highScore,this.score.highestLevel,this.score.bestCombo,newRecord);
  }
  private frame=(now:number):void=>{
    if(this.disposed)return;const dt=Math.min((now-(this.lastFrame||now))/1000,.05);this.lastFrame=now;
    if(this.states.canPlay()){
      this.physics.step(now);this.input.update(dt);this.balls.sync();
      this.mergeManager.detect(now);this.mergeManager.update(now);this.score.update(now);
      this.effects.update(dt);this.checkDanger(now);
      this.ui.score(this.score.score,this.saved.highScore);this.ui.combo(this.score.combo,this.score.comboPoints);
      if(this.score.highestLevel>this.saved.highestBallLevel)this.saved.highestBallLevel=this.score.highestLevel;
    }else if(this.states.state===GameState.Paused){this.effects.update(0);}
    else this.effects.update(dt);
    this.scene.render(now);this.adaptQuality(dt);this.raf=requestAnimationFrame(this.frame);
  };
  private mergeManager!:MergeManager;
  private resize=():void=>this.scene.resize();
  private visibility=():void=>{this.physics.resetClock();};
  private lowFps=0;
  private adaptQuality(dt:number):void {
    if(dt>1/35)this.lowFps+=dt;else this.lowFps=Math.max(0,this.lowFps-dt*.5);
    if(this.lowFps>3&&!this.reduced){this.reduced=true;this.scene.renderer.setPixelRatio(Math.min(window.devicePixelRatio,1));this.effects.setReduced(true);this.scene.renderer.shadowMap.enabled=false;}
  }
  async boot():Promise<void>{await this.init();this.mergeManager=new MergeManager(this.balls,this.score,this.effects,this.audio,(level,points,combo)=>{
    if(level>=4)this.scene.shake(.018*(level-2),Math.min(300,80+level*25));
    if(!this.saved.tutorialCompleted&&this.dropCount>0){this.ui.hint('DUE SFERE UGUALI SI FONDONO');this.saved.tutorialCompleted=true;StorageManager.save(this.saved);}
    this.ui.combo(combo,this.score.comboPoints);
  });}
  dispose():void {this.disposed=true;cancelAnimationFrame(this.raf);this.input.dispose();this.dropper.dispose();this.balls.dispose();this.effects.dispose();this.physics.dispose();this.scene.dispose();window.removeEventListener('resize',this.resize);document.removeEventListener('visibilitychange',this.visibility);}
}
