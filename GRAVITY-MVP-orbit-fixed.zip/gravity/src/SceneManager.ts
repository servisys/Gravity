import * as THREE from 'three';
import { CHAMBER } from './config';

export class SceneManager {
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  world = new THREE.Group();
  chamberEdges = new THREE.Group();
  private target = new THREE.Vector3(0, 6.5, 0);
  private baseCamera = new THREE.Vector3(0, 7.5, 24);
  private spherical = new THREE.Spherical();
  private shakePower = 0;
  private shakeUntil = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.scene.background = new THREE.Color(0x050b16);
    this.scene.fog = new THREE.FogExp2(0x050b16, .025);
    this.camera = new THREE.PerspectiveCamera(40, 1, .1, 100);
    this.camera.position.copy(this.baseCamera);
    this.camera.lookAt(this.target);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;
    this.scene.add(this.world);
    this.buildLights();
    this.buildChamber();
    this.resize();
    this.resetView();
  }

  private buildLights(): void {
    this.scene.add(new THREE.HemisphereLight(0x9bc9ff, 0x101321, 1.3));
    const key = new THREE.DirectionalLight(0xc5e6ff, 2.2); key.position.set(-5, 12, 9); this.scene.add(key);
    const cyan = new THREE.PointLight(0x21cfff, 24, 22); cyan.position.set(-5, 8, 1); this.scene.add(cyan);
    const violet = new THREE.PointLight(0x714dff, 18, 18); violet.position.set(5, 11, -1); this.scene.add(violet);
  }

  private buildChamber(): void {
    const { width, height, depth } = CHAMBER;
    const glass = new THREE.MeshPhysicalMaterial({ color: 0x12253b, metalness: .35, roughness: .18, transparent: true, opacity: .16, side: THREE.DoubleSide });
    const back = new THREE.Mesh(new THREE.PlaneGeometry(width, height), glass); back.position.set(0, height / 2, -depth / 2); this.world.add(back);
    const floorMat = new THREE.MeshStandardMaterial({ color: 0x18283a, metalness: .8, roughness: .24 });
    const floor = new THREE.Mesh(new THREE.BoxGeometry(width + .5, .32, depth + .4), floorMat); floor.position.set(0, -.16, 0); this.world.add(floor);
    const wallMat = new THREE.MeshPhysicalMaterial({ color: 0x13243a, metalness: .45, roughness: .2, transparent: true, opacity: .13 });
    for (const x of [-width / 2 - .12, width / 2 + .12]) { const w = new THREE.Mesh(new THREE.BoxGeometry(.24, height, depth), wallMat); w.position.set(x, height / 2, 0); this.world.add(w); }
    const edgeMat = new THREE.LineBasicMaterial({ color: 0x39cfff });
    const edgePoints = [
      [[-width/2,0,depth/2],[width/2,0,depth/2]], [[-width/2,height,depth/2],[width/2,height,depth/2]],
      [[-width/2,0,depth/2],[-width/2,height,depth/2]], [[width/2,0,depth/2],[width/2,height,depth/2]],
      [[-width/2,0,-depth/2],[-width/2,height,-depth/2]], [[width/2,0,-depth/2],[width/2,height,-depth/2]]
    ];
    for (const pair of edgePoints) {
      const geo = new THREE.BufferGeometry().setFromPoints(pair.map(p => new THREE.Vector3(...p as [number, number, number])));
      this.chamberEdges.add(new THREE.Line(geo, edgeMat));
    }
    this.world.add(this.chamberEdges);
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xff4568, transparent: true, opacity: .82 });
    const line = new THREE.Mesh(new THREE.BoxGeometry(width, .025, depth + .08), lineMat); line.position.set(0, CHAMBER.criticalLineY, 0); line.name = 'critical-line'; this.world.add(line);
    const grid = new THREE.GridHelper(20, 40, 0x18334b, 0x102236); grid.position.y = .012; grid.scale.set(1, .4, .3); this.world.add(grid);
    const topGlow = new THREE.Mesh(new THREE.BoxGeometry(width, .04, .05), new THREE.MeshBasicMaterial({ color: 0x38cfff })); topGlow.position.set(0, height, depth / 2); this.world.add(topGlow);
  }

  private updateCamera(): void {
    this.camera.position.setFromSpherical(this.spherical).add(this.target);
    this.camera.lookAt(this.target);
  }

  orbit(deltaX: number, deltaY: number): void {
    this.spherical.theta -= deltaX * .006;
    this.spherical.phi = THREE.MathUtils.clamp(this.spherical.phi + deltaY * .006, .72, 1.48);
    this.updateCamera();
  }

  resetView(): void {
    const offset = this.baseCamera.clone().sub(this.target);
    this.spherical.setFromVector3(offset);
    this.updateCamera();
  }

  resize(): void {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.baseCamera.z = this.camera.aspect < .7 ? 31 : 24;
    // Preserve the current orbit angle while adapting the default viewing distance.
    const theta = this.spherical.theta || 0;
    const phi = this.spherical.phi || Math.acos((this.baseCamera.y - this.target.y) / this.baseCamera.distanceTo(this.target));
    const distance = this.baseCamera.distanceTo(this.target);
    this.spherical.set(phi, theta, distance);
    this.camera.updateProjectionMatrix();
    this.updateCamera();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  shake(intensity: number, duration: number): void {
    this.shakePower = Math.max(this.shakePower, intensity);
    this.shakeUntil = performance.now() + duration;
  }

  render(now: number): void {
    const remaining = this.shakeUntil - now;
    if (remaining > 0) {
      const p = this.shakePower * (remaining / 300);
      this.camera.position.x += (Math.random() - .5) * p;
      this.camera.position.y += (Math.random() - .5) * p;
    } else this.shakePower = 0;
    this.camera.lookAt(this.target);
    this.renderer.render(this.scene, this.camera);
  }

  dispose(): void { this.renderer.dispose(); }
}
