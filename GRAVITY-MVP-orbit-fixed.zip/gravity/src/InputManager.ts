import * as THREE from 'three';
import { CHAMBER } from './config';
import { DropController } from './DropController';
import { StateMachine } from './GameState';
import { SceneManager } from './SceneManager';

export class InputManager {
  private raycaster = new THREE.Raycaster();
  private plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);
  private pointerDown = false;
  private startY = 0;
  private moved = false;
  private keys = new Set<string>();
  private activeTouches = new Map<number, { x: number; y: number }>();
  private orbiting = false;
  private orbitPointerId: number | null = null;
  private lastOrbit = { x: 0, y: 0 };

  constructor(
    private canvas: HTMLCanvasElement,
    private scene: SceneManager,
    private dropper: DropController,
    private states: StateMachine,
    private onDrop: () => void,
    private onPause: () => void
  ) {
    canvas.addEventListener('pointerdown', this.down);
    canvas.addEventListener('pointermove', this.move);
    canvas.addEventListener('pointerup', this.up);
    canvas.addEventListener('pointercancel', this.up);
    canvas.addEventListener('contextmenu', this.contextMenu);
    window.addEventListener('keydown', this.keyDown);
    window.addEventListener('keyup', this.keyUp);
  }

  private point = (e: PointerEvent): void => {
    const r = this.canvas.getBoundingClientRect();
    const p = new THREE.Vector2((e.clientX-r.left)/r.width*2-1, -((e.clientY-r.top)/r.height*2-1));
    this.raycaster.setFromCamera(p, this.scene.camera);
    const target = new THREE.Vector3();
    if (this.raycaster.ray.intersectPlane(this.plane, target))
      this.dropper.move(THREE.MathUtils.clamp(target.x, CHAMBER.dropMinX, CHAMBER.dropMaxX));
  };

  private down = (e: PointerEvent): void => {
    if (!this.states.canPlay()) return;
    if (e.pointerType === 'touch') {
      this.activeTouches.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.activeTouches.size >= 2) {
        this.orbiting = true;
        this.orbitPointerId = e.pointerId;
        this.lastOrbit = { x: e.clientX, y: e.clientY };
        this.pointerDown = false;
        this.canvas.setPointerCapture?.(e.pointerId);
        return;
      }
    }
    if (e.pointerType === 'mouse' && (e.button === 2 || e.shiftKey)) {
      this.orbiting = true;
      this.orbitPointerId = e.pointerId;
      this.lastOrbit = { x: e.clientX, y: e.clientY };
      this.canvas.setPointerCapture?.(e.pointerId);
      return;
    }
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    this.pointerDown = true;
    this.startY = e.clientY;
    this.moved = false;
    this.canvas.setPointerCapture?.(e.pointerId);
    this.point(e);
  };

  private move = (e: PointerEvent): void => {
    if (!this.states.canPlay()) return;
    if (this.orbiting && this.orbitPointerId === e.pointerId) {
      const dx = e.clientX - this.lastOrbit.x;
      const dy = e.clientY - this.lastOrbit.y;
      this.lastOrbit = { x: e.clientX, y: e.clientY };
      this.scene.orbit(dx, dy);
      if (e.pointerType === 'touch') this.activeTouches.set(e.pointerId, { x: e.clientX, y: e.clientY });
      return;
    }
    if (e.pointerType === 'mouse' && !this.pointerDown) {
      if (e.buttons === 0) this.point(e);
    }
    if (this.pointerDown) {
      if (Math.abs(e.clientY - this.startY) > 8) this.moved = true;
      this.point(e);
    }
  };

  private up = (e: PointerEvent): void => {
    if (e.pointerType === 'touch') this.activeTouches.delete(e.pointerId);
    if (this.orbiting) {
      if (this.activeTouches.size < 2) {
        this.orbiting = false;
        this.orbitPointerId = null;
        this.pointerDown = false;
      }
      return;
    }
    if (!this.pointerDown) return;
    this.pointerDown = false;
    if (this.states.canPlay()) this.onDrop();
  };

  private contextMenu = (e: Event): void => e.preventDefault();

  private keyDown = (e: KeyboardEvent): void => {
    if (e.key === 'Escape') { this.onPause(); return; }
    if (['ArrowLeft', 'ArrowRight', ' ', 'a', 'd', 'A', 'D'].includes(e.key)) e.preventDefault();
    if (!this.states.canPlay()) return;
    if (e.key === ' ') { this.onDrop(); return; }
    this.keys.add(e.key.toLowerCase());
  };

  private keyUp = (e: KeyboardEvent): void => { this.keys.delete(e.key.toLowerCase()); };

  update(dt: number): void {
    if (!this.states.canPlay()) return;
    const speed = 7 * dt;
    if (this.keys.has('arrowleft') || this.keys.has('a')) this.dropper.move(this.dropper.x - speed);
    if (this.keys.has('arrowright') || this.keys.has('d')) this.dropper.move(this.dropper.x + speed);
  }

  dispose(): void {
    this.canvas.removeEventListener('pointerdown', this.down);
    this.canvas.removeEventListener('pointermove', this.move);
    this.canvas.removeEventListener('pointerup', this.up);
    this.canvas.removeEventListener('pointercancel', this.up);
    this.canvas.removeEventListener('contextmenu', this.contextMenu);
    window.removeEventListener('keydown', this.keyDown);
    window.removeEventListener('keyup', this.keyUp);
  }
}
