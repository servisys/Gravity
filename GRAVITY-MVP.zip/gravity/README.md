# GRAVITY — Drop. Merge. Survive.

A self-contained 3D physics merge puzzle built with Vite, TypeScript, Three.js and Rapier.

## Run locally

```bash
npm install
npm run dev
```

Open the URL printed by Vite (normally http://localhost:5173).

## Production build

```bash
npm run build
npm run preview
```

## Controls

- Mouse: move with the pointer, click to drop.
- Touch: drag to position, release to drop.
- Keyboard: A/D or arrow keys to move, Space to drop, Esc to pause.

The game uses procedural geometry, materials, particles and Web Audio; no game assets need to be downloaded.
