import * as THREE from 'three';
import { CHAMBER, GAME_BALANCE, LEVELS, SPAWN_SEQUENCE } from './config';
import { BallManager } from './BallManager';
import type { Ball } from './types';
export class DropController {
  x=0; nextLevel=1; private queue:number[]=[]; private sequenceIndex=0; private lastDrop=0;
  private preview:THREE.Group; private guide:THREE.Line; private canDrop=false;
  constructor(private scene:THREE.Group,private balls:BallManager){
    this.preview=new THREE.Group();this.scene.add(this.preview);
    const geo=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3(0,-9,0)]);
    this.guide=new THREE.Line(geo,new THREE.LineDashedMaterial({color:0x72dfff,dashSize:.18,gapSize:.16,transparent:true,opacity:.38}));this.scene.add(this.guide);
    this.resetQueue();this.updatePreview();
  }
  private resetQueue():void {this.queue=[];this.sequenceIndex=0;for(let i=0;i<5;i++)this.queue.push(this.nextRandom());this.nextLevel=this.queue.shift()!;}
  private nextRandom():number {
    if(this.sequenceIndex<SPAWN_SEQUENCE.length)return SPAWN_SEQUENCE[this.sequenceIndex++];
    const weights=[65,28,7],n=Math.random()*100;let level=n<weights[0]?1:n<weights[0]+weights[1]?2:3;
    const recent=this.queue.slice(-4);if(recent.length===4&&recent.every(v=>v===level))level=level%3+1;return level;
  }
  private refill():void {while(this.queue.length<5)this.queue.push(this.nextRandom());}
  updatePreview():void {
    const cfg=LEVELS[this.nextLevel-1];
    this.preview.traverse((o:THREE.Object3D)=>{if(o instanceof THREE.Mesh){o.geometry.dispose();if(Array.isArray(o.material))o.material.forEach((m:THREE.Material)=>m.dispose());else o.material.dispose();}});
    this.preview.clear();
    const mat=new THREE.MeshPhysicalMaterial({color:cfg.color,emissive:cfg.emissive,emissiveIntensity:.75,roughness:.22,metalness:.2,clearcoat:.8});
    this.preview.add(new THREE.Mesh(new THREE.SphereGeometry(cfg.radius,28,20),mat));
    this.preview.position.set(this.x,CHAMBER.spawnY,0);
    const pts=[new THREE.Vector3(this.x,CHAMBER.spawnY-cfg.radius,0),new THREE.Vector3(this.x,cfg.radius,0)];
    this.guide.geometry.dispose();this.guide.geometry=new THREE.BufferGeometry().setFromPoints(pts);
    this.guide.computeLineDistances();
  }
  move(x:number):void {this.x=THREE.MathUtils.clamp(x,CHAMBER.dropMinX,CHAMBER.dropMaxX);this.preview.position.x=this.x;this.updateGuide();}
  private updateGuide():void {const a=this.guide.geometry.attributes.position as THREE.BufferAttribute;a.setX(0,this.x);a.setX(1,this.x);a.needsUpdate=true;this.guide.computeLineDistances();}
  setEnabled(v:boolean):void {this.canDrop=v;this.preview.visible=v;this.guide.visible=v;}
  drop(now:number):Ball|null {
    if(!this.canDrop||now-this.lastDrop<GAME_BALANCE.spawnCooldownMs||this.balls.activeCount>=GAME_BALANCE.maxActiveBalls)return null;
    this.lastDrop=now;this.canDrop=false;this.preview.visible=false;this.guide.visible=false;
    const level=this.nextLevel;
    const ball=this.balls.create(level,new THREE.Vector3(this.x,CHAMBER.spawnY,0),new THREE.Vector3(0,-.3,0),'active');
    this.nextLevel=this.queue.shift()!;this.refill();this.updatePreview();return ball;
  }
  readyForNext():void {this.setEnabled(true);}
  reset():void {this.x=0;this.lastDrop=0;this.resetQueue();this.setEnabled(false);this.updatePreview();}
  dispose():void {this.preview.traverse((o:THREE.Object3D)=>{if(o instanceof THREE.Mesh){o.geometry.dispose();if(Array.isArray(o.material))o.material.forEach((m:THREE.Material)=>m.dispose());else o.material.dispose();}});this.scene.remove(this.preview);this.scene.remove(this.guide);this.guide.geometry.dispose();(this.guide.material as THREE.Material).dispose();}
}
