import { GameState } from './types';
export class StateMachine {
  private current = GameState.Loading;
  private listeners = new Set<(s:GameState,prev:GameState)=>void>();
  get state(): GameState { return this.current; }
  canPlay(): boolean { return this.current===GameState.Playing || this.current===GameState.Danger; }
  set(next: GameState): void {
    if (next===this.current) return;
    const allowed: Record<GameState,GameState[]> = {
      [GameState.Loading]:[GameState.Ready], [GameState.Ready]:[GameState.Playing],
      [GameState.Playing]:[GameState.Danger,GameState.Paused,GameState.GameOver],
      [GameState.Danger]:[GameState.Playing,GameState.Paused,GameState.GameOver],
      [GameState.Paused]:[GameState.Playing,GameState.Danger,GameState.Ready],
      [GameState.GameOver]:[GameState.Ready]
    };
    if (!allowed[this.current].includes(next)) return;
    const prev=this.current; this.current=next; this.listeners.forEach(fn=>fn(next,prev));
  }
  onChange(fn:(s:GameState,prev:GameState)=>void):()=>void { this.listeners.add(fn); return ()=>this.listeners.delete(fn); }
}
