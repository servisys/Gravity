import './styles.css';
import { Game } from './Game';
const game=new Game();
game.boot().catch(error=>{console.error('GRAVITY boot failed',error);document.body.insertAdjacentHTML('beforeend','<div class="fatal">Impossibile avviare la simulazione. Ricarica la pagina.</div>');});
window.addEventListener('beforeunload',()=>game.dispose(),{once:true});
