export const CHAMBER = {
  width: 10, height: 16, depth: 4, criticalLineY: 13.2, spawnY: 15,
  dropMinX: -4.4, dropMaxX: 4.4
} as const;
export const GAME_BALANCE = {
  spawnCooldownMs: 450, comboWindowMs: 2200, dangerEntryDelayMs: 500,
  gameOverCountdownMs: 3000, maxActiveBalls: 70, maxSpawnLevel: 3,
  gravity: -14, criticalLineY: 13.2, tutorialDrops: 10, fixedStep: 1/60,
  maxFrameDelta: 0.05, mergeDistanceFactor: 1.035, maxMergeRelativeSpeed: 8
} as const;
export const LEVELS = [
  { name:'SPARK', radius:.42, color:0x47d9ff, points:2, emissive:0x087ca5, symbol:'✦', freq:261.63 },
  { name:'PULSE', radius:.52, color:0x65ff9b, points:6, emissive:0x0d9a55, symbol:'Ⅱ', freq:293.66 },
  { name:'FLUX', radius:.64, color:0xf6ff4b, points:18, emissive:0x9c9e08, symbol:'◈', freq:329.63 },
  { name:'NOVA', radius:.78, color:0xff9a45, points:54, emissive:0xa94b08, symbol:'✧', freq:392 },
  { name:'PLASMA', radius:.94, color:0xff4d68, points:162, emissive:0x9f102c, symbol:'✹', freq:440 },
  { name:'VOID', radius:1.10, color:0x9b68ff, points:486, emissive:0x5120a5, symbol:'◉', freq:523.25 },
  { name:'QUANTUM', radius:1.28, color:0xffc5ef, points:1458, emissive:0x9c4c91, symbol:'✺', freq:659.25 },
  { name:'SINGULARITY', radius:1.48, color:0x101827, points:4374, emissive:0x9e62ff, symbol:'●', freq:783.99 }
] as const;
export const SPAWN_SEQUENCE = [1,1,2,1,1,2,2,1,3,1];
export const COMBO_MULTIPLIERS = [1,1.5,2,3,5,8];
export const PHYSICS = { restitution:.12, friction:.65, linearDamping:.18, angularDamping:.35 };
