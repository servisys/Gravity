import { LEVELS } from './config';
export class AudioManager {
  private ctx: AudioContext | null=null; private enabled=true; private master: GainNode | null=null;
  setEnabled(v:boolean):void { this.enabled=v; if(this.master) this.master.gain.value=v?.22:0; }
  private init():void {
    if(this.ctx) return;
    const Ctx = window.AudioContext;
    this.ctx = new Ctx(); this.master=this.ctx.createGain(); this.master.gain.value=this.enabled?.22:0; this.master.connect(this.ctx.destination);
  }
  private tone(freq:number,duration:number,type:OscillatorType='sine',gain=.18,slide=0):void {
    if(!this.enabled) return; this.init(); const c=this.ctx!;
    if(c.state==='suspended') void c.resume();
    const o=c.createOscillator(), g=c.createGain(); o.type=type; o.frequency.setValueAtTime(freq,c.currentTime);
    if(slide) o.frequency.exponentialRampToValueAtTime(Math.max(30,freq+slide),c.currentTime+duration);
    g.gain.setValueAtTime(.0001,c.currentTime); g.gain.exponentialRampToValueAtTime(gain,c.currentTime+.012);
    g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+duration); o.connect(g); g.connect(this.master!); o.start(); o.stop(c.currentTime+duration+.03);
  }
  drop():void { this.tone(180,.09,'triangle',.07,-70); }
  merge(level:number,combo:number):void { const f=LEVELS[Math.min(7,level-1)].freq; this.tone(f,.25,level>=5?'sawtooth':'sine',.16+Math.min(combo,6)*.012,f*.18); if(level>=5)this.tone(f/2,.32,'sine',.09); }
  danger(progress:number):void { this.tone(100+progress*35,.12,'sine',.08); }
  gameOver():void { this.tone(95,.65,'triangle',.2,-55); }
  record():void { [523,659,784].forEach((f,i)=>setTimeout(()=>this.tone(f,.22,'sine',.13),i*95)); }
}
