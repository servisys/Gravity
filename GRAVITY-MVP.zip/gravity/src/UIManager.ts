import { GameState } from './types';
export class UIManager {
  private el=(id:string)=>document.getElementById(id)!;
  private screens=['start-screen','pause-screen','over-screen'];
  showScreen(id:string|null):void {this.screens.forEach(s=>this.el(s).classList.toggle('active',s===id));}
  setState(s:GameState):void {this.el('hud').classList.toggle('visible',s===GameState.Playing||s===GameState.Danger||s===GameState.Paused);this.el('next-panel').classList.toggle('visible',s===GameState.Playing||s===GameState.Danger);}
  score(score:number,best:number):void {this.el('score').textContent=score.toLocaleString('it-IT').padStart(6,'0');this.el('best').textContent=best.toLocaleString('it-IT');this.el('menu-best').textContent=best.toLocaleString('it-IT');}
  next(name:string,color:number):void {(this.el('next-orb') as HTMLElement).style.background=`radial-gradient(circle at 32% 28%,#fff8,${'#'+color.toString(16).padStart(6,'0')} 48%,#07111d 100%)`;this.el('next-name').textContent=name;}
  combo(count:number,points:number):void {const e=this.el('combo');e.innerHTML=count>1?`<strong>COMBO x${count}</strong><span>+${points.toLocaleString('it-IT')}</span>`:'';e.classList.toggle('show',count>1);}
  danger(seconds:number):void {this.el('danger-banner').classList.add('show');this.el('danger-count').textContent=seconds.toFixed(1);}
  clearDanger():void {this.el('danger-banner').classList.remove('show');}
  hint(text:string):void {const e=this.el('hint');e.textContent=text;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),1900);}
  gameOver(score:number,best:number,level:number,combo:number,newRecord:boolean):void {this.el('final-score').textContent=score.toLocaleString('it-IT');this.el('final-best').textContent=best.toLocaleString('it-IT');this.el('final-level').textContent=['','SPARK','PULSE','FLUX','NOVA','PLASMA','VOID','QUANTUM','SINGULARITY'][level];this.el('final-combo').textContent=`x${combo}`;this.el('new-record').classList.toggle('show',newRecord);this.showScreen('over-screen');}
  sound(enabled:boolean):void {this.el('sound-btn').textContent=enabled?'♫ AUDIO ON':'♫ AUDIO OFF';}
  bind(id:string,fn:()=>void):void {this.el(id).addEventListener('click',fn);}
}
