import type * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';

export enum GameState { Loading='Loading', Ready='Ready', Playing='Playing', Danger='Danger', Paused='Paused', GameOver='GameOver' }
export type BallStatus = 'spawning' | 'active' | 'merging' | 'destroyed';
export interface Ball {
  id: number; level: number; mesh: THREE.Group; body: RAPIER.RigidBody;
  collider: RAPIER.Collider; status: BallStatus; createdAt: number; dangerSince: number | null;
}
export interface SavedData {
  version: number; highScore: number; highestBallLevel: number; bestCombo: number;
  gamesPlayed: number; soundEnabled: boolean; musicEnabled: boolean; tutorialCompleted: boolean;
}
export interface MergeEvent { level: number; position: THREE.Vector3; intensity: number; points: number; chain: number; }
