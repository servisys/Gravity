import RAPIER from '@dimforge/rapier3d-compat';
import { CHAMBER, GAME_BALANCE, PHYSICS } from './config';
export class PhysicsManager {
  world!:RAPIER.World; private accumulator=0; private last=0;
  async init():Promise<void>{
    await RAPIER.init(); this.world=new RAPIER.World({x:0,y:GAME_BALANCE.gravity,z:0}); this.world.timestep=GAME_BALANCE.fixedStep;
    const fixed=RAPIER.RigidBodyDesc.fixed();
    const add=(x:number,y:number,z:number,hx:number,hy:number,hz:number)=>{const b=this.world.createRigidBody(fixed.setTranslation(x,y,z));this.world.createCollider(RAPIER.ColliderDesc.cuboid(hx,hy,hz).setRestitution(PHYSICS.restitution).setFriction(PHYSICS.friction),b);};
    add(0,-.2,0,CHAMBER.width/2+.4,.2,CHAMBER.depth/2+.3);
    add(-CHAMBER.width/2-.1,CHAMBER.height/2,0,.1,CHAMBER.height/2,CHAMBER.depth/2+.3);
    add(CHAMBER.width/2+.1,CHAMBER.height/2,0,.1,CHAMBER.height/2,CHAMBER.depth/2+.3);
    add(0,CHAMBER.height/2,-CHAMBER.depth/2-.1,CHAMBER.width/2,CHAMBER.height/2,.1);
    add(0,CHAMBER.height/2,CHAMBER.depth/2+.1,CHAMBER.width/2,CHAMBER.height/2,.1);
    this.last=performance.now();
  }
  step(now:number):void {
    if(!this.world)return;
    const dt=Math.min((now-this.last)/1000,GAME_BALANCE.maxFrameDelta);this.last=now;this.accumulator+=Math.max(0,dt);
    let steps=0;while(this.accumulator>=GAME_BALANCE.fixedStep&&steps<4){this.world.step();this.accumulator-=GAME_BALANCE.fixedStep;steps++;}
    if(steps===4)this.accumulator=0;
  }
  resetClock():void {this.last=performance.now();this.accumulator=0;}
  dispose():void {this.world?.free();}
}
