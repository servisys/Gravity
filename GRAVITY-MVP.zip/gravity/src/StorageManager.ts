import type { SavedData } from './types';
const KEY = 'gravity_save_v1';
const DEFAULTS: SavedData = { version:1, highScore:0, highestBallLevel:1, bestCombo:1, gamesPlayed:0, soundEnabled:true, musicEnabled:false, tutorialCompleted:false };
export class StorageManager {
  static load(): SavedData {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return {...DEFAULTS};
      const parsed = JSON.parse(raw) as Partial<SavedData>;
      const num = (v: unknown, fallback:number, min=0) => typeof v === 'number' && Number.isFinite(v) ? Math.max(min, Math.floor(v)) : fallback;
      return {
        version:1, highScore:num(parsed.highScore,0), highestBallLevel:Math.min(8,num(parsed.highestBallLevel,1,1)),
        bestCombo:Math.min(8,num(parsed.bestCombo,1,1)), gamesPlayed:num(parsed.gamesPlayed,0),
        soundEnabled:typeof parsed.soundEnabled==='boolean'?parsed.soundEnabled:true,
        musicEnabled:typeof parsed.musicEnabled==='boolean'?parsed.musicEnabled:false,
        tutorialCompleted:typeof parsed.tutorialCompleted==='boolean'?parsed.tutorialCompleted:false
      };
    } catch { return {...DEFAULTS}; }
  }
  static save(data: SavedData): void { try { localStorage.setItem(KEY, JSON.stringify(data)); } catch { /* storage may be unavailable */ } }
}
