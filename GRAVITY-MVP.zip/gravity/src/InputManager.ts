import * as THREE from 'three';
import { CHAMBER } from './config';
import { DropController } from './DropController';
import { StateMachine } from './GameState';
export class InputManager {
  private raycaster=new THREE.Raycaster();private plane=new THREE.Plane(new THREE.Vector3(0,0,1),0);
  private pointerDown=false;private startY=0;private moved=false;private keys=new Set<string>();
  constructor(private canvas:HTMLCanvasElement,private camera:THREE.Camera,private dropper:DropController,private states:StateMachine,private onDrop:()=>void,private onPause:()=>void){
    canvas.addEventListener('pointerdown',this.down);canvas.addEventListener('pointermove',this.move);canvas.addEventListener('pointerup',this.up);canvas.addEventListener('pointercancel',this.up);
    window.addEventListener('keydown',this.keyDown);window.addEventListener('keyup',this.keyUp);
  }
  private point=(e:PointerEvent):void=>{
    const r=this.canvas.getBoundingClientRect(),p=new THREE.Vector2((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height*2-1));
    this.raycaster.setFromCamera(p,this.camera);const target=new THREE.Vector3();if(this.raycaster.ray.intersectPlane(this.plane,target))this.dropper.move(THREE.MathUtils.clamp(target.x,CHAMBER.dropMinX,CHAMBER.dropMaxX));
  };
  private down=(e:PointerEvent):void=>{if(!this.states.canPlay())return;this.pointerDown=true;this.startY=e.clientY;this.moved=false;this.canvas.setPointerCapture?.(e.pointerId);this.point(e);};
  private move=(e:PointerEvent):void=>{if(!this.states.canPlay())return;if(e.pointerType==='mouse'&&!this.pointerDown)this.point(e);if(this.pointerDown){if(Math.abs(e.clientY-this.startY)>8)this.moved=true;this.point(e);}};
  private up=(e:PointerEvent):void=>{if(!this.pointerDown)return;this.pointerDown=false;if(this.states.canPlay()){if(!this.moved||e.pointerType==='mouse')this.onDrop();else this.onDrop();}};
  private keyDown=(e:KeyboardEvent):void=>{
    if(e.key==='Escape'){this.onPause();return;}
    if(['ArrowLeft','ArrowRight',' ','a','d','A','D'].includes(e.key))e.preventDefault();
    if(!this.states.canPlay())return;
    if(e.key===' '){this.onDrop();return;}
    this.keys.add(e.key.toLowerCase());
  };
  private keyUp=(e:KeyboardEvent):void=>{this.keys.delete(e.key.toLowerCase());};
  update(dt:number):void {if(!this.states.canPlay())return;const speed=7*dt;if(this.keys.has('arrowleft')||this.keys.has('a'))this.dropper.move(this.dropper.x-speed);if(this.keys.has('arrowright')||this.keys.has('d'))this.dropper.move(this.dropper.x+speed);}
  dispose():void {this.canvas.removeEventListener('pointerdown',this.down);this.canvas.removeEventListener('pointermove',this.move);this.canvas.removeEventListener('pointerup',this.up);this.canvas.removeEventListener('pointercancel',this.up);window.removeEventListener('keydown',this.keyDown);window.removeEventListener('keyup',this.keyUp);}
}
