import { COMBO_MULTIPLIERS, GAME_BALANCE, LEVELS } from './config';
export class ScoreManager {
  score=0; combo=0; bestCombo=1; lastMerge=0; comboPoints=0; highestLevel=1;
  addMerge(level:number,now:number):{points:number,multiplier:number,combo:number} {
    if(now-this.lastMerge>GAME_BALANCE.comboWindowMs) { this.combo=0; this.comboPoints=0; }
    this.combo++; this.lastMerge=now; this.bestCombo=Math.max(this.bestCombo,this.combo);
    const multiplier=COMBO_MULTIPLIERS[Math.min(this.combo-1,COMBO_MULTIPLIERS.length-1)];
    const points=Math.round(LEVELS[level-1].points*multiplier);
    this.score+=points; this.comboPoints+=points; this.highestLevel=Math.max(this.highestLevel,level);
    return {points,multiplier,combo:this.combo};
  }
  update(now:number):boolean { if(this.combo>0 && now-this.lastMerge>GAME_BALANCE.comboWindowMs){this.combo=0;this.comboPoints=0;return true;} return false; }
  reset():void { this.score=0;this.combo=0;this.bestCombo=1;this.lastMerge=0;this.comboPoints=0;this.highestLevel=1; }
}
