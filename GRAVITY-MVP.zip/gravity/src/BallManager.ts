import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';
import type { Ball } from './types';
import { CHAMBER, LEVELS, PHYSICS } from './config';
export class BallManager {
  private balls=new Map<number,Ball>(); private nextId=1;
  private geometries=LEVELS.map(l=>new THREE.SphereGeometry(l.radius,28,20));
  private materials=LEVELS.map((l,i)=>new THREE.MeshPhysicalMaterial({color:l.color,metalness:.22,roughness:.23,clearcoat:.8,clearcoatRoughness:.15,emissive:l.emissive,emissiveIntensity:.48+i*.09}));
  constructor(private scene:THREE.Group,private world:RAPIER.World){}
  get all():Ball[]{return [...this.balls.values()].filter(b=>b.status!=='destroyed');}
  get activeCount():number{return this.all.filter(b=>b.status==='active').length;}
  get(id:number):Ball|undefined{return this.balls.get(id);}
  create(level:number,position:THREE.Vector3,velocity=new THREE.Vector3(),status:'spawning'|'active'='active'):Ball|null {
    const cfg=LEVELS[level-1]; if(!cfg)return null;
    const x=THREE.MathUtils.clamp(position.x,-CHAMBER.width/2+cfg.radius,CHAMBER.width/2-cfg.radius);
    const y=THREE.MathUtils.clamp(position.y,cfg.radius+.02,CHAMBER.height-cfg.radius-.02);
    const z=THREE.MathUtils.clamp(position.z,-CHAMBER.depth/2+cfg.radius,CHAMBER.depth/2-cfg.radius);
    const body=this.world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(x,y,z).setLinearDamping(PHYSICS.linearDamping).setAngularDamping(PHYSICS.angularDamping).setCanSleep(true));
    const collider=this.world.createCollider(RAPIER.ColliderDesc.ball(cfg.radius).setRestitution(PHYSICS.restitution).setFriction(PHYSICS.friction).setDensity(1),body);
    const group=new THREE.Group();
    const sphere=new THREE.Mesh(this.geometries[level-1],this.materials[level-1]); sphere.castShadow=true; sphere.receiveShadow=true; group.add(sphere);
    const detail=new THREE.Mesh(new THREE.TorusGeometry(cfg.radius*.47,.018,6,32),new THREE.MeshBasicMaterial({color:level===8?0xb78cff:0xffffff,transparent:true,opacity:.42}));
    detail.rotation.x=Math.PI/2; group.add(detail);
    const glyph=new THREE.Sprite(new THREE.SpriteMaterial({map:this.makeGlyph(LEVELS[level-1].symbol),transparent:true,opacity:.72,depthWrite:false}));
    glyph.scale.set(cfg.radius*.72,cfg.radius*.72,1); glyph.position.z=cfg.radius*.88; group.add(glyph);
    group.position.set(x,y,z); this.scene.add(group);
    body.setLinvel({x:velocity.x,y:velocity.y,z:velocity.z},true);
    const ball:Ball={id:this.nextId++,level,mesh:group,body,collider,status,createdAt:performance.now(),dangerSince:null};
    this.balls.set(ball.id,ball); return ball;
  }
  private makeGlyph(symbol:string):THREE.CanvasTexture {
    const c=document.createElement('canvas');c.width=128;c.height=128;const ctx=c.getContext('2d')!;
    ctx.fillStyle='#ffffff';ctx.font='bold 76px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(symbol,64,68);
    const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;
  }
  sync():void {for(const b of this.balls.values()){if(b.status==='destroyed'||b.status==='merging')continue;const p=b.body.translation();b.mesh.position.set(p.x,p.y,p.z);const r=b.body.rotation();b.mesh.quaternion.set(r.x,r.y,r.z,r.w);}}
  position(b:Ball):THREE.Vector3 {const p=b.body.translation();return new THREE.Vector3(p.x,p.y,p.z);}
  velocity(b:Ball):THREE.Vector3 {const v=b.body.linvel();return new THREE.Vector3(v.x,v.y,v.z);}
  remove(b:Ball):void {if(b.status==='destroyed')return;b.status='destroyed';this.scene.remove(b.mesh);b.mesh.traverse((o:THREE.Object3D)=>{if(o instanceof THREE.Sprite){(o.material as THREE.SpriteMaterial).map?.dispose();}else if(o instanceof THREE.Mesh && o.geometry!==this.geometries[b.level-1]){o.geometry.dispose();if(Array.isArray(o.material))o.material.forEach((m:THREE.Material)=>m.dispose());else o.material.dispose();}});this.world.removeRigidBody(b.body);this.balls.delete(b.id);}
  clear():void {for(const b of [...this.balls.values()])this.remove(b);}
  dispose():void {this.clear();this.geometries.forEach(g=>g.dispose());this.materials.forEach(m=>m.dispose());}
}
