import * as THREE from 'three';
import { LEVELS } from './config';
type Particle={mesh:THREE.Mesh,velocity:THREE.Vector3,life:number,maxLife:number};
export class EffectsManager {
  private particles:Particle[]=[]; private rings:Array<{mesh:THREE.Mesh,life:number,max:number}>=[];
  private sphereGeo=new THREE.SphereGeometry(.035,6,6); private ringGeo=new THREE.TorusGeometry(1,.018,5,48);
  constructor(private scene:THREE.Group){}
  merge(pos:THREE.Vector3,level:number):void {
    const color=LEVELS[level-1].color,count=level<=2?10:level<=5?14:20;
    const ring=new THREE.Mesh(this.ringGeo,new THREE.MeshBasicMaterial({color,transparent:true,opacity:.9}));ring.position.copy(pos);ring.rotation.x=Math.PI/2;ring.scale.setScalar(.2);this.scene.add(ring);this.rings.push({mesh:ring,life:0,max:.38});
    for(let i=0;i<count;i++){
      let p=this.particles.find(x=>x.life<=0);
      if(!p && this.particles.length<150){const mesh=new THREE.Mesh(this.sphereGeo,new THREE.MeshBasicMaterial({color,transparent:true,opacity:1}));this.scene.add(mesh);p={mesh,velocity:new THREE.Vector3(),life:0,maxLife:.55};this.particles.push(p);}
      if(!p)continue;
      const a=Math.random()*Math.PI*2,e=(Math.random()-.5)*Math.PI*.7,s=.8+Math.random()*2.8;
      p.mesh.position.copy(pos);p.velocity.set(Math.cos(a)*Math.cos(e)*s,Math.sin(e)*s,Math.sin(a)*Math.cos(e)*s);p.life=.35+Math.random()*.3;p.maxLife=p.life;p.mesh.visible=true;
    }
  }
  update(dt:number):void {
    for(const p of this.particles){if(p.life<=0)continue;p.life-=dt;p.velocity.y-=3*dt;p.mesh.position.addScaledVector(p.velocity,dt);(p.mesh.material as THREE.MeshBasicMaterial).opacity=Math.max(0,p.life/p.maxLife);if(p.life<=0)p.mesh.visible=false;}
    for(let i=this.rings.length-1;i>=0;i--){const r=this.rings[i];r.life+=dt;const t=r.life/r.max;r.mesh.scale.setScalar(.2+t*2.2);(r.mesh.material as THREE.MeshBasicMaterial).opacity=1-t;if(t>=1){this.scene.remove(r.mesh);r.mesh.geometry.dispose();(r.mesh.material as THREE.Material).dispose();this.rings.splice(i,1);}}
  }
  reset():void { for(const p of this.particles){p.life=0;p.mesh.visible=false;} for(const r of this.rings){this.scene.remove(r.mesh);(r.mesh.material as THREE.Material).dispose();} this.rings=[]; }
  setReduced(reduced:boolean):void {if(reduced)this.particles.forEach(p=>{if(p.life>0)p.life=Math.min(p.life,.15);});}
  dispose():void {for(const p of this.particles){this.scene.remove(p.mesh);(p.mesh.material as THREE.Material).dispose();}for(const r of this.rings){this.scene.remove(r.mesh);(r.mesh.material as THREE.Material).dispose();}this.sphereGeo.dispose();this.ringGeo.dispose();this.particles=[];this.rings=[];}
}
