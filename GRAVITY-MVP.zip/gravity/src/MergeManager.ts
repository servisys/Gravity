import * as THREE from 'three';
import type { Ball } from './types';
import { GAME_BALANCE, LEVELS } from './config';
import { BallManager } from './BallManager';
import { ScoreManager } from './ScoreManager';
import { EffectsManager } from './EffectsManager';
import { AudioManager } from './AudioManager';
export class MergeManager {
  private locked=new Set<number>(); private pending:Array<{a:Ball,b:Ball,at:number,position:THREE.Vector3,velocity:THREE.Vector3}>=[];
  constructor(private balls:BallManager,private score:ScoreManager,private effects:EffectsManager,private audio:AudioManager,private onMerge:(level:number,points:number,combo:number)=>void){}
  detect(now:number):void {
    const list=this.balls.all.filter(b=>b.status==='active'&&b.level<8&&!this.locked.has(b.id)).sort((a,b)=>a.id-b.id);
    const candidates:Array<{a:Ball,b:Ball,d:number}>=[];
    for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length;j++){
      const a=list[i],b=list[j];if(a.level!==b.level)continue;
      const pa=this.balls.position(a),pb=this.balls.position(b),r=LEVELS[a.level-1].radius+LEVELS[b.level-1].radius;
      const d=pa.distanceTo(pb);if(d>r*GAME_BALANCE.mergeDistanceFactor)continue;
      if(this.balls.velocity(a).sub(this.balls.velocity(b)).length()>GAME_BALANCE.maxMergeRelativeSpeed)continue;
      candidates.push({a,b,d});
    }
    candidates.sort((x,y)=>x.d-y.d||x.a.id-y.a.id||x.b.id-y.b.id);
    const chosen=new Set<number>();
    for(const c of candidates){if(chosen.has(c.a.id)||chosen.has(c.b.id))continue;this.begin(c.a,c.b,now);chosen.add(c.a.id);chosen.add(c.b.id);}
  }
  private begin(a:Ball,b:Ball,now:number):void {
    if(a.status!=='active'||b.status!=='active'||this.locked.has(a.id)||this.locked.has(b.id))return;
    const pa=this.balls.position(a),pb=this.balls.position(b),va=this.balls.velocity(a),vb=this.balls.velocity(b);
    const pos=pa.add(pb).multiplyScalar(.5);pos.y+=.08;
    const vel=va.add(vb).multiplyScalar(.35);
    a.status='merging';b.status='merging';a.body.setEnabled(false);b.body.setEnabled(false);this.locked.add(a.id);this.locked.add(b.id);
    this.pending.push({a,b,at:now,position:pos,velocity:vel});
  }
  update(now:number):void {
    const done=this.pending.filter(p=>now-p.at>=115);
    this.pending=this.pending.filter(p=>now-p.at<115);
    for(const p of done){
      this.balls.remove(p.a);this.balls.remove(p.b);
      const level=p.a.level+1;
      const result=this.balls.create(level,p.position,p.velocity);
      this.locked.delete(p.a.id);this.locked.delete(p.b.id);
      if(!result)continue;
      const gain=this.score.addMerge(level,now);
      this.effects.merge(p.position,level);
      this.audio.merge(level,gain.combo);
      this.onMerge(level,gain.points,gain.combo);
    }
  }
  reset():void {this.pending=[];this.locked.clear();}
}
